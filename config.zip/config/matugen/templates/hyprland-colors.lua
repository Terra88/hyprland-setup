return {
    primary = "rgba({{colors.primary.default.hex_stripped}}ee)",
    secondary = "rgba({{colors.secondary.default.hex_stripped}}ee)",
    surface = "rgba({{colors.surface.default.hex_stripped}}dd)",
    inactive = "rgba({{colors.outline_variant.default.hex_stripped}}88)",
}

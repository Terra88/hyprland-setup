-- Hybrid GPU & Wayland Environment (verify card0/card1 order via: ls -l /dev/dri/by-path/)
hl.env("AQ_DRM_DEVICES", "/dev/dri/card1:/dev/dri/card0")
hl.env("LIBVA_DRIVER_NAME", "nvidia")
hl.env("NVD_BACKEND", "direct")
hl.env("ELECTRON_OZONE_PLATFORM_HINT", "auto")

-- Cursor, Desktop & Qt Theme
hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")
hl.env("XDG_CURRENT_DESKTOP", "Hyprland")
hl.env("XDG_SESSION_TYPE", "wayland")
hl.env("XDG_SESSION_DESKTOP", "Hyprland")
hl.env("XDG_MENU_PREFIX", "arch-")
hl.env("QT_STYLE_OVERRIDE", "kvantum")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("QT_QPA_PLATFORMTHEME", "qt5ct")


-- Load Modular Config
require("lua.monitors")
require("lua.options")
require("lua.keybinds")
require("lua.rules")

-- Autostart
hl.on("hyprland.start", function()
hl.exec_cmd("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP XDG_MENU_PREFIX")
hl.exec_cmd("waybar")
hl.exec_cmd("hyprpaper")
hl.exec_cmd("~/.config/hypr/scripts/monitor_reload.sh")
hl.exec_cmd("systemctl --user start plasma-polkit-agent")
hl.exec_cmd("systemctl --user start gamemoded")
hl.exec_cmd("kbuildsycoca6")
end)

return {
    primary = "rgba(ffb3b1ee)",
    secondary = "rgba(e6bdbbee)",
    surface = "rgba(1a1111dd)",
    inactive = "rgba(52434288)",
}

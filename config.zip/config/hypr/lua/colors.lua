return {
    primary = "rgba(b0c6ffee)",
    secondary = "rgba(c0c6dcee)",
    surface = "rgba(121318dd)",
    inactive = "rgba(44464f88)",
}

return {
    primary = "rgba(b9c3ffee)",
    secondary = "rgba(c3c5ddee)",
    surface = "rgba(121318dd)",
    inactive = "rgba(46464f88)",
}

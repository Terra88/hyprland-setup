return {
    primary = "rgba(9fcafcee)",
    secondary = "rgba(bac8dbee)",
    surface = "rgba(101418dd)",
    inactive = "rgba(42474e88)",
}

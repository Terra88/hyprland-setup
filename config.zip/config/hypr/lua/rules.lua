-- Automatically route workspace 1 to HDMI-A-1 whenever connected
hl.workspace_rule({
    workspace = "1",
    monitor = "HDMI-A-1",
    default = true,
})

-- Gamescope low-latency rules
hl.window_rule({
    match = { class = "^(gamescope)$" },
               immediate = true,
               no_blur = true,
               no_shadow = true,
               fullscreen = true,
})

-- Steam / Proton games low-latency tearing
hl.window_rule({
    match = { class = "^(steam_app_.*)$" },
               immediate = true,
})

-- Dolphin transparency + Hyprland blur
hl.window_rule({
    match = { class = "^(org\\.kde\\.dolphin)$" },
    opacity = "0.85 0.80",
})




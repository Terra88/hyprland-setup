-- Internal laptop display / Main Display()
hl.monitor({
    output = "eDP-1",
    mode = "preferred",
    position = "auto",
    scale = 1,
    vrr = 1,
})


-- Fallback monitor or 2nd monitor
hl.monitor({
    output = "HDI-A-1",
    mode = "highres",
    position = "auto",
    scale = 1.0,
})

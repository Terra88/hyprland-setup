-- Internal laptop display
hl.monitor({
    output = "eDP-1",
    mode = "preferred",
    position = "auto",
    scale = 1,
    vrr = 2, -- 2 = VRR active in fullscreen games only (prevents desktop flicker)
})

-- External HDMI monitor (wired directly to RTX 5070)
hl.monitor({
    output = "HDMI-A-1",
    mode = "highres",
    position = "auto",
    scale = 1.0,
    vrr = 2,
})

-- Fallback for any other external display (USB-C / DP)
hl.monitor({
    output = "",
    mode = "preferred",
    position = "auto",
    scale = 1.0,
})

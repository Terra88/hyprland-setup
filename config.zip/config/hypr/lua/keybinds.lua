local mod = "SUPER"

local terminal = "kitty"
local fileManager = "dolphin"
local menu = "rofi -show drun -normal-window"
local browser = "firefox"

-- Core & App Binds
local binds = {
    { mod .. " + RETURN",    hl.dsp.exec_cmd(terminal, {tile = true}) },
    { mod .. " + Q",         hl.dsp.window.close() },
    { mod .. " + M",         hl.dsp.exit() },
    { mod .. " + B",         hl.dsp.exec_cmd(browser) },
    { mod .. " + E",         hl.dsp.exec_cmd(fileManager) },
    { mod .. " + V",         hl.dsp.window.float({ action = "toggle" }) },
    { mod .. " + R",         hl.dsp.exec_cmd(menu) },
    { mod .. " + P",         hl.dsp.window.pseudo() },
    { mod .. " + SHIFT + W", hl.dsp.exec_cmd('"$HOME/.config/wallpaper.sh"') },

    -- Focus Movement
    { mod .. " + left",      hl.dsp.focus({ direction = "left" }) },
    { mod .. " + right",     hl.dsp.focus({ direction = "right" }) },
    { mod .. " + up",        hl.dsp.focus({ direction = "up" }) },
    { mod .. " + down",      hl.dsp.focus({ direction = "down" }) },

    -- Special Workspace (Scratchpad)
    { mod .. " + S",         hl.dsp.workspace.toggle_special("magic") },
    { mod .. " + SHIFT + S", hl.dsp.window.move({ workspace = "special:magic" }) },

    -- Mouse Workspace Scroll & Window Drag/Resize
    { mod .. " + mouse_down", hl.dsp.focus({ workspace = "e+1" }) },
    { mod .. " + mouse_up",   hl.dsp.focus({ workspace = "e-1" }) },
    { mod .. " + mouse:272",  hl.dsp.window.drag() },
    { mod .. " + mouse:273",  hl.dsp.window.resize() },
}

for _, b in ipairs(binds) do
    hl.bind(b[1], b[2])
    end

    -- Workspaces 1–10 (0 maps to workspace 10)
    for i = 1, 10 do
        local key = (i == 10) and "0" or tostring(i)
        hl.bind(mod .. " + " .. key, hl.dsp.focus({ workspace = i }))
        hl.bind(mod .. " + SHIFT + " .. key, hl.dsp.window.move({ workspace = i }))
        end

        -- Hardware Media & Brightness Keys
        local mediaBinds = {
            { "XF86AudioRaiseVolume",  "wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+",  { locked = true, repeating = true } },
            { "XF86AudioLowerVolume",  "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-",       { locked = true, repeating = true } },
            { "XF86AudioMute",         "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle",      { locked = true, repeating = true } },
            { "XF86AudioMicMute",      "wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle",    { locked = true, repeating = true } },
            { "XF86MonBrightnessUp",   "brightnessctl -e4 -n2 set 5%+",                   { locked = true, repeating = true } },
            { "XF86MonBrightnessDown", "brightnessctl -e4 -n2 set 5%-",                   { locked = true, repeating = true } },
            { "XF86AudioNext",         "playerctl next",                                  { locked = true } },
            { "XF86AudioPause",        "playerctl play-pause",                            { locked = true } },
            { "XF86AudioPlay",         "playerctl play-pause",                            { locked = true } },
            { "XF86AudioPrev",         "playerctl previous",                              { locked = true } },
        }

        for _, m in ipairs(mediaBinds) do
            hl.bind(m[1], hl.dsp.exec_cmd(m[2]), m[3])
            end

#!/usr/bin/env bash
WALLPAPER_DIR="$HOME/wallpaper/nature-culture"

if [ -n "$1" ] && [ -f "$1" ]; then
  WALL="$1"
else
  WALL="$(find "$WALLPAPER_DIR" -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) | shuf -n 1)"
fi

if [ -z "$WALL" ] || [ ! -f "$WALL" ]; then
  notify-send "Wallpaper Error" "No images found in $WALLPAPER_DIR"
  exit 1
fi

# Recover automatically if daemon isn't responding
if ! awww query >/dev/null 2>&1; then
  pkill -9 awww-daemon 2>/dev/null
  rm -f "$XDG_RUNTIME_DIR"/*awww*.sock
  awww-daemon >/dev/null 2>&1 &
  until awww query >/dev/null 2>&1; do
    sleep 0.1
  done
fi

awww img "$WALL" \
  --transition-type grow \
  --transition-pos 0.95,0.98 \
  --transition-step 90 \
  --transition-fps 144

matugen image "$WALL" --source-color-index 0

killall -SIGUSR2 waybar 2>/dev/null || waybar >/dev/null 2>&1 &
killall -SIGUSR1 kitty 2>/dev/null
swaync-client -rs 2>/dev/null

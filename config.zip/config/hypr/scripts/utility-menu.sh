#!/usr/bin/env bash

show_themes() {
  CHOICE=$(printf "󰸉  Next Random Wallpaper (Auto Colors)\n󰏘  Catppuccin Mocha Pink\n󰏘  Tokyo Night\n󰏘  Gruvbox Dark\n󰋩  Pick Specific Wallpaper" | rofi -dmenu -i -p "Theme")
  case "$CHOICE" in
    *"Random Wallpaper"*) ~/.config/hypr/scripts/theme-switch.sh ;;
    *"Catppuccin"*) matugen color hex "#f5c2e7" && killall -SIGUSR2 waybar && killall -SIGUSR1 kitty ;;
    *"Tokyo Night"*) matugen color hex "#7aa2f7" && killall -SIGUSR2 waybar && killall -SIGUSR1 kitty ;;
    *"Gruvbox"*) matugen color hex "#fabd2f" && killall -SIGUSR2 waybar && killall -SIGUSR1 kitty ;;
    *"Pick Specific"*)
      IMG=$(find "$HOME/wallpaper" -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) | rofi -dmenu -i -p "Wallpaper")
      [ -n "$IMG" ] && ~/.config/hypr/scripts/theme-switch.sh "$IMG"
      ;;
  esac
}

if [[ "$1" == "themes" ]]; then
  show_themes
  exit 0
fi

ACTION=$(printf "󰏘  Themes & Wallpapers\n󰂯  Bluetooth Manager\n󰕾  Audio Mixer (Pavucontrol)\n󰍹  Display Layout (nwg-displays)\n󰌾  Lock Screen\n󰤄  Suspend\n󰜉  Reboot\n󰐥  Shutdown" | rofi -dmenu -i -p "Utilities")

case "$ACTION" in
  *"Themes"*) show_themes ;;
  *"Bluetooth"*) blueman-manager ;;
  *"Audio"*) pavucontrol ;;
  *"Display"*) nwg-displays ;;
  *"Lock"*) hyprlock ;;
  *"Suspend"*) systemctl suspend ;;
  *"Reboot"*) systemctl reboot ;;
  *"Shutdown"*) systemctl poweroff ;;
esac

#!/usr/bin/env bash

apply_hex() {
  local hex="$1"
  local mode="${2:-dark}"
  matugen color hex "$hex" --source-color-index 0 --mode "$mode"
  killall -SIGUSR2 waybar 2>/dev/null || waybar >/dev/null 2>&1 &
  killall -SIGUSR1 kitty 2>/dev/null
  swaync-client -rs 2>/dev/null
}

show_themes() {
  CHOICE=$(printf "󰸉  Next Random Wallpaper (Auto Colors)\n󰋩  Pick Specific Wallpaper\n󰏘  Catppuccin Mocha Pink\n󰏘  Tokyo Night\n󰏘  Gruvbox Dark\n󰏘  Nord\n󰏘  Dracula\n󰏘  Rose Pine\n󰏘  Everforest\n󰖨  Light Mode (Clean)" | rofi -dmenu -i -p "Theme")
  case "$CHOICE" in
    *"Random Wallpaper"*) ~/.config/hypr/scripts/theme-switch.sh ;;
    *"Pick Specific"*)
      IMG=$(find "$HOME/wallpaper" -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) | rofi -dmenu -i -p "Wallpaper")
      [ -n "$IMG" ] && ~/.config/hypr/scripts/theme-switch.sh "$IMG"
      ;;
    *"Catppuccin"*)  apply_hex "#f5c2e7" ;;
    *"Tokyo Night"*) apply_hex "#7aa2f7" ;;
    *"Gruvbox"*)     apply_hex "#fabd2f" ;;
    *"Nord"*)        apply_hex "#88c0d0" ;;
    *"Dracula"*)     apply_hex "#bd93f9" ;;
    *"Rose Pine"*)   apply_hex "#ebbcba" ;;
    *"Everforest"*)  apply_hex "#a7c080" ;;
    *"Light Mode"*)  apply_hex "#5c7cfa" "light" ;;
  esac
}

if [[ "$1" == "themes" ]]; then
  show_themes
  exit 0
fi

ACTION=$(printf "󰏘  Themes & Wallpapers\n󰂯  Bluetooth Manager\n󰕾  Audio Mixer (Pavucontrol)\n󰍹  Display Layout (nwg-displays)\n󰌾  Lock Screen\n󰤄  Suspend\n󰜉  Reboot\n󰐥  Shutdown" | rofi -dmenu -i -p "Utilities")

case "$ACTION" in
  *"Themes"*)    show_themes ;;
  *"Bluetooth"*) blueman-manager ;;
  *"Audio"*)     pavucontrol ;;
  *"Display"*)   nwg-displays ;;
  *"Lock"*)      hyprlock ;;
  *"Suspend"*)   systemctl suspend ;;
  *"Reboot"*)    systemctl reboot ;;
  *"Shutdown"*)  systemctl poweroff ;;
esac

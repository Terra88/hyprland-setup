#!/usr/bin/env bash
notify-send "Wi-Fi" "Scanning networks..." -t 1500

# List unique non-empty SSIDs with security and signal strength
LIST=$(nmcli -t -f IN-USE,SSID,SECURITY,SIGNAL dev wifi list --rescan yes | \
  awk -F: '$2 != "" {
    mark = ($1 == "*") ? "󰄬 " : "   ";
    printf "%s%-28s  [%s]  %s%%\n", mark, $2, ($3 == "" ? "OPEN" : $3), $4
  }' | awk '!seen[$0]++')

CHOSEN=$(echo "$LIST" | rofi -dmenu -i -p "Wi-Fi")
[ -z "$CHOSEN" ] && exit 0

# Extract clean SSID
SSID=$(echo "$CHOSEN" | sed -E 's/^(󰄬 |   )//; s/  +\[.*//')

if nmcli -t -f NAME connection show | grep -Fxq "$SSID"; then
  nmcli connection up "$SSID" && notify-send "Wi-Fi" "Connected to $SSID"
else
  PASS=$(rofi -dmenu -password -p "Password for $SSID")
  [ -n "$PASS" ] && nmcli dev wifi connect "$SSID" password "$PASS" && notify-send "Wi-Fi" "Connected to $SSID"
fi
